package com.example.GCBatch.utils;

import java.io.File;

public class FileIO {

    public static boolean FileExistsInDirectory(File Directory, File file) {
        for(File fileInDirectory : Directory.listFiles()){
            if(fileInDirectory.getName().equals(file.getName())){
                return true;
            }
        }
        return false;
    }
}
