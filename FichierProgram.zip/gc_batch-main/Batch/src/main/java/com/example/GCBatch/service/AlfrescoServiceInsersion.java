package com.example.GCBatch.service;

import com.example.GCBatch.constant.Constant;
import com.example.GCBatch.repository.AlfrescoRepository;
import com.example.GCBatch.utils.FileIO;

import javax.activation.MimetypesFileTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class AlfrescoServiceInsersion {

    public static final String rootDirectory = Constant.rootDirectory;
    public AlfrescoRepository alfrescoRepository = new AlfrescoRepository();
    MimetypesFileTypeMap mimetypesFileTypeMap = new MimetypesFileTypeMap();
    File root = new File(rootDirectory);
    public void insertDocumentInAlfresco(String rootId,String directoryPath) throws IOException {
        File file = new File(directoryPath);
        for(File childFiles : file.listFiles()){
            if(childFiles.isDirectory()){
                if(alfrescoRepository.FolderExist(rootId,childFiles.getName())  && !childFiles.getName().equalsIgnoreCase("OCR") && !childFiles.getName().equalsIgnoreCase("Fusion")&& !childFiles.getName().equalsIgnoreCase("PDF") && !childFiles.getName().equalsIgnoreCase("FileNonTraite")){
                    alfrescoRepository.createFolder(rootId,childFiles.getName());
                }
                String[] folders = childFiles.getAbsolutePath().split("\\\\");
                List<String> foldersList = Arrays.asList(folders);
                if(foldersList.size()-foldersList.lastIndexOf(root.getName())==6){
                    File OCRFolder = new File(childFiles.getAbsolutePath()+"\\"+"OCR");
                    File FusionFolder = new File(childFiles.getAbsolutePath()+"\\"+"Fusion");
                    if(!FileIO.FileExistsInDirectory(new File(childFiles.getAbsolutePath()),new File(childFiles.getAbsolutePath()+"\\"+"finTraitement.clos"))){
                        if(FusionFolder.exists()){
                            for(File pdfFiles: FusionFolder.listFiles()){
                                try {
                                    alfrescoRepository.createDocument(alfrescoRepository.getFolderId(rootId, childFiles.getName()),pdfFiles,mimetypesFileTypeMap.getContentType(file));
                                    System.out.println("inserting "+alfrescoRepository.getFolderId(rootId, childFiles.getName()));
                                }
                                catch (Exception e){
                                    System.out.println("Error creating document "+e.getMessage());
                                }
                            }
                        }
                        if(OCRFolder.exists()){
                            for(File pdfFiles: OCRFolder.listFiles()){
                                try {
                                    alfrescoRepository.createDocument(alfrescoRepository.getFolderId(rootId, childFiles.getName()),pdfFiles,mimetypesFileTypeMap.getContentType(file));
                                    System.out.println("inserting "+alfrescoRepository.getFolderId(rootId, childFiles.getName()));
                                }
                                catch (Exception e){
                                    System.out.println("Error creating document "+e.getMessage());
                                }
                            }
                        }
                        Path pathOfFileFinTraitement = Paths.get(childFiles.getAbsolutePath()+"\\"+"finTraitement.clos");
                        Files.createFile(pathOfFileFinTraitement);
                    }
                }


                insertDocumentInAlfresco(alfrescoRepository.getFolderId(rootId, childFiles.getName()),childFiles.getAbsolutePath());
            }
        }
    }
}
