package com.example.GCBatch.task;

import com.example.GCBatch.constant.Constant;
import com.example.GCBatch.service.AlfrescoServiceInsersion;
import com.example.GCBatch.session.AlfrescoSession;
import com.example.GCBatch.utils.FileIO;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.quartz.JobExecutionException;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import static org.apache.pdfbox.pdfparser.PDFParser.load;

public class MaTask {
    Folder root = AlfrescoSession.getSession().getRootFolder();
    public AlfrescoServiceInsersion alfrescoServiceInsersion = new AlfrescoServiceInsersion();

    public final String directoryPath = Constant.rootDirectory;


    public void execute () throws JobExecutionException {
//        convertImageToPdf(directoryPath);
//        try {
//            movePdfToFusion(directoryPath);
//        } catch (IOException e) {
//            System.out.println("Exception in moving " + e.getMessage());
//        }

        try {
            mkidr(directoryPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            MainFolder(directoryPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            decoupPdfFiles(directoryPath);
        } catch (IOException e) {
            System.out.println("Exception in decoupage " + e.getMessage());
        }
        try {
            FusionPDF(directoryPath);
        } catch (IOException e) {
            System.out.println("Exception in fusion " + e.getMessage());

        }
        try {
            renamePdfFiles(directoryPath);
        } catch (IOException e) {
            System.out.println("Exception in rename " + e.getMessage());
        }
        try {
            alfrescoServiceInsersion.insertDocumentInAlfresco(root.getId(), directoryPath);
        } catch (FileNotFoundException e) {
            System.out.println("Exception in insert " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Exception in insert " + e.getMessage());
        }
    }
    private static  void FusionPDF(String directoryPath) throws IOException {
        File rootDirectory = new File(directoryPath);
        for (File pdfDirectory : rootDirectory.listFiles()) {
            if (pdfDirectory.isDirectory()) {
                if (!pdfDirectory.getName().equalsIgnoreCase("OCR")) {
                    FusionPDF(pdfDirectory.getAbsolutePath());
                    } else if (pdfDirectory.getName().equalsIgnoreCase("OCR") && pdfDirectory.listFiles().length > 1) {
                    Path pdfOCRPath = Paths.get(pdfDirectory.getAbsolutePath());
                    Path FusionPDFDirectoryPath = pdfOCRPath.getParent();
                    mergePdf(pdfDirectory.getAbsolutePath(), FusionPDFDirectoryPath.toString() + "\\" + "Fusion");
                }
            }
        }
    }
    private static void mergePdf(String pdfDirectory, String destDirectory) throws IOException {
        File destPdfDirectory = new File(destDirectory);
        if (!destPdfDirectory.exists()) {
            destPdfDirectory.mkdirs();
        }
        String[] directoriesName = destDirectory.split("\\\\");
        String mergedPdfName = directoriesName[directoriesName.length - 2] + "_" + directoriesName[directoriesName.length - 6] + "_" + directoriesName[directoriesName.length - 5] + "_" + directoriesName[directoriesName.length - 4] + "_" + directoriesName[directoriesName.length - 3];
        File pdfFileDirectory = new File(pdfDirectory);
        PDFMergerUtility pdfmerger = new PDFMergerUtility();
        for (File pdfFile : pdfFileDirectory.listFiles()) {
            PDDocument document = load(pdfFile);
            pdfmerger.setDestinationFileName(destDirectory + "\\" + mergedPdfName+".pdf");
            pdfmerger.addSource(pdfFile);
            document.close();
        }
        pdfmerger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly());
    }
    private void movePdfToFusion(String directoryPath) throws IOException {
        File rootDirectory = new File(directoryPath);
        for (File pdfFilesDirectories : rootDirectory.listFiles()) {
            if (pdfFilesDirectories.isDirectory()) {
                if (!pdfFilesDirectories.getName().equalsIgnoreCase("PDF")) {
                    movePdfToFusion(pdfFilesDirectories.getAbsolutePath());
                } else {
                    Path pdfFilesDirectoriesPath = Paths.get(pdfFilesDirectories.getAbsolutePath());
                    Path FusionPDFDirectoryPath = pdfFilesDirectoriesPath.getParent();
                    File FusionFile = new File(FusionPDFDirectoryPath.toString() + "\\" + "Fusion");
                    if (!FusionFile.exists()) {
                        FusionFile.mkdirs();
                    }
                    if (pdfFilesDirectories.listFiles().length > 1) {
                        String[] directoriesName = FusionFile.toString().split("\\\\");
                        String mergedPdfName = directoriesName[directoriesName.length - 2] + "_" + directoriesName[directoriesName.length - 6] + "_" + directoriesName[directoriesName.length - 5] + "_" + directoriesName[directoriesName.length - 4] + "_" + directoriesName[directoriesName.length - 3];
                        Files.move(Objects.requireNonNull(pdfFilesDirectories.listFiles())[0].toPath(), Objects.requireNonNull(pdfFilesDirectories.listFiles())[0].toPath().resolveSibling(mergedPdfName + '.' + FilenameUtils.getExtension(Objects.requireNonNull(pdfFilesDirectories.listFiles())[0].getName())), StandardCopyOption.REPLACE_EXISTING);
                        if (!FileIO.FileExistsInDirectory(FusionFile, Objects.requireNonNull(pdfFilesDirectories.listFiles())[0])) {
                            FileUtils.copyFileToDirectory(Objects.requireNonNull(pdfFilesDirectories.listFiles())[0], FusionFile);
                        }
                    }
                }
            }
        }
    }
    private static void convertImageToPdf(String directoryPath) {
        File rootDirectory = new File(directoryPath);
        for (File file : rootDirectory.listFiles()) {
            if (file.isDirectory()) {
                if (!file.getName().equalsIgnoreCase("IMG")) {
                    convertImageToPdf(file.getPath());
                } else if (file.getName().equalsIgnoreCase("IMG")) {
                    Path imgPath = Paths.get(file.getAbsolutePath());
                    Path NumberDirectory = imgPath.getParent();
                    if(!FileIO.FileExistsInDirectory(new File(NumberDirectory.toString()),new File(NumberDirectory.toString()+"\\"+"finTraitement.clos"))){
                        for (File imageFile : file.listFiles()) {
                            try {
                                PDDocument document = new PDDocument();
                                InputStream in = new FileInputStream(imageFile.getAbsolutePath());
                                BufferedImage bimg = ImageIO.read(in);
                                float width = bimg.getWidth();
                                float height = bimg.getHeight();
                                PDPage page = new PDPage(new PDRectangle(width, height));
                                document.addPage(page);
                                PDImageXObject img = PDImageXObject.createFromFile(imageFile.getAbsolutePath(), document);
                                PDPageContentStream contentStream = new PDPageContentStream(document, page);
                                contentStream.drawImage(img, 0, 0);
                                contentStream.close();
                                in.close();
                                Path imagePath = Paths.get(imageFile.getAbsolutePath());
                                Path imagePathParentFolder = imagePath.getParent();
                                Path NumberJournalPathFolder = imagePathParentFolder.getParent();
                                String NO_OCR_Path = NumberJournalPathFolder.toString() + "/" + "PDFSP";
                                File NoOcrFolder = new File(NO_OCR_Path);
                                if (!NoOcrFolder.exists()) {
                                    NoOcrFolder.mkdirs();
                                }
                                System.out.println("save PDF " + NO_OCR_Path + "/" + FilenameUtils.removeExtension(imageFile.getName()) + ".pdf");
                                document.save(NO_OCR_Path + "/" + FilenameUtils.removeExtension(imageFile.getName()) + ".pdf");
                                document.close();
                                System.out.println("end");

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }

    }

    /*private void convertPdfToPdfA(String directoryPath) {
        File fileDirectory = new File(directoryPath);
        for (File pdfFile : fileDirectory.listFiles()) {
            if (pdfFile.isDirectory()) {
                if (!pdfFile.getName().equals("OCR")) {
                    convertPdfToPdfA(pdfFile.getAbsolutePath());
                } else if (pdfFile.getName().equals("OCR")) {
                    for (File fileNoOcr : pdfFile.listFiles()) {
                        Path pdfPathPath = Paths.get(fileNoOcr.getAbsolutePath());
                        Path pdfPathParentFolder = pdfPathPath.getParent();
                        Path NumberJournalPathFolder = pdfPathParentFolder.getParent();
                        String OCR_Path = NumberJournalPathFolder.toString() + "/" + "OCR";
                        File OcrFolder = new File(OCR_Path);
                        if (!OcrFolder.exists()) {
                            OcrFolder.mkdirs();
                        }
                        String desPath = OCR_Path + "/" + FilenameUtils.removeExtension(pdfFile.getName()) + ".pdf";
                        ApiOcrCall.convertPdfToPdfA(pdfFile.getAbsolutePath(), desPath);
                    }

                }
            }
        }
    }*/
    private void decoupPdfFiles(String directoryPath) throws IOException {
        File rootDirectory = new File(directoryPath);
        for (File pdfFile : rootDirectory.listFiles()) {
            if (pdfFile.isDirectory()) {
                if (!pdfFile.getName().equalsIgnoreCase("PDF")) {
                    decoupPdfFiles(pdfFile.getAbsolutePath());
                } else if (pdfFile.getName().equalsIgnoreCase("PDF")) {
                    Path pdfPath = Paths.get(pdfFile.getAbsolutePath());
                    Path pdfDirectory = pdfPath.getParent();
                    if(!FileIO.FileExistsInDirectory(new File(pdfDirectory.toString()),new File(pdfDirectory.toString()+"\\"+"finTraitement.clos"))){
                        File[] pdfFiles = pdfFile.listFiles();
                        Path parentPdfPath = Paths.get(pdfFiles[0].getAbsolutePath()).getParent();
                        Path parentInputPdfPath = parentPdfPath.getParent();
                        MaTask.decoupagePdf(pdfFiles[0].getAbsolutePath(), parentInputPdfPath.toString() + "\\" + "OCR");
                    }
                }
            }
        }
    }
    private static void renamePdfFiles(String directoryPath) throws IOException {
        File  rootDirectory = new File(directoryPath);
        for (File pdfFiles : rootDirectory.listFiles()) {
            if (pdfFiles.isDirectory()) {
                if (!pdfFiles.getName().equalsIgnoreCase("OCR")) {
                    renamePdfFiles(pdfFiles.getAbsolutePath());
                } else if (pdfFiles.getName().equalsIgnoreCase("OCR")) {
                    Path pdfPath = Paths.get(pdfFiles.getAbsolutePath());
                    Path pdfDirectory = pdfPath.getParent();
                    if(!FileIO.FileExistsInDirectory(new File(pdfDirectory.toString()),new File(pdfDirectory.toString()+"\\"+"finTraitement.clos"))){
                        String pathOCRDirectory = pdfFiles.getAbsolutePath();
                        String[] pathElement = pathOCRDirectory.split("\\\\");
                        String buildName = pathElement[pathElement.length - 2] + "_" + pathElement[pathElement.length - 6] + "_" + pathElement[pathElement.length - 5] + "_" + pathElement[pathElement.length - 4] + "_" + pathElement[pathElement.length - 3];
                        int i = 0;
                        for (File pdfFile : pdfFiles.listFiles()) {
                            try {
                                i = i + 1;
                                Files.move(pdfFile.toPath(), pdfFile.toPath().resolveSibling(buildName + "_" + i + ".pdf"), StandardCopyOption.REPLACE_EXISTING);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                    }
                }
            }
        }
    }
    private static void decoupagePdf(String pdfPath, String pdfDest) throws IOException {
        File pdfFile = new File(pdfPath);
        File pdfFileDest = new File(pdfDest);
        if (!pdfFileDest.exists()) {
            pdfFileDest.mkdirs();
        }
        PDDocument document = load(pdfFile);
        Splitter splitter = new Splitter();
        List<PDDocument> Pages = splitter.split(document);
        Iterator<PDDocument> iterator = Pages.listIterator();
        int i = 1;
        while (iterator.hasNext()) {
            PDDocument pd = iterator.next();
            pd.save(pdfDest + "\\" + i++ + ".pdf");
            System.out.println("saved" + pdfDest + "\\" + i++ + ".pdf");
        }
        System.out.println("Multiple PDF’s created");
        document.close();
    }
    private void mkidr(String directoryPath) throws IOException {
        File file = new File(directoryPath);
        for (File subFile : file.listFiles()){
            if (IsValideName(subFile.getName(), "\\d+_[A-Za-z]+_\\d{4}_\\w+_\\d{2}") || IsValideName(subFile.getName(), "\\d+_[A-Za-z]+_\\d{4}_\\w+_\\d{2}_\\d+.\\w+")){
                String[] SplitsubFileName = subFile.getName().split("[_-]");
                Path path = Paths.get(Constant.rootDirectory + "//" + SplitsubFileName[1] + "//" + SplitsubFileName[2] + "//" + SplitsubFileName[3] + "//" + SplitsubFileName[4] + "//" + SplitsubFileName[0]);
                File Folder = new File(String.valueOf(path));
                if (!Folder.exists()){
                    Folder.mkdirs();
                }
                if(subFile.isDirectory() && IsValideName(subFile.getName(), "\\d+_[A-Za-z]+_\\d{4}_\\w+_\\d{2}")){
                    for (File pdfFiles : subFile.listFiles()){
                        File finclos = new File(Folder.getPath()+"//"+"finTraitement.clos");
                        if(!finclos.exists()){
                            try {
                                Path target = Paths.get(Folder+"//"+pdfFiles.getName());
                                Files.move(pdfFiles.toPath(),target,StandardCopyOption.REPLACE_EXISTING);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                    if(subFile.listFiles().length==0){
                        Files.delete(subFile.toPath());
                    }else{
                        FileUtils.deleteDirectory(subFile);
                    }


                }
                if(subFile.isFile() && IsValideName(subFile.getName(), "\\d+_[A-Za-z]+_\\d{4}_\\w+_\\d{2}") && SplitsubFileName.length>1 && isValideTypeFile(subFile.getName(),"pdf")) {
                    Path source = Paths.get(subFile.getPath());
                    Path target = Paths.get(Folder.getPath() + "//" + subFile.getName());
                    if (!FileIO.FileExistsInDirectory(Folder,subFile)){
                        Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
                    }
                } else if (SplitsubFileName.length == 6 && isValideTypeFile(subFile.getName(), "pdf")) {
                    Date currentDate = new Date();
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("SSS");
                    String NewName = SplitsubFileName[0] + "_" + SplitsubFileName[1] + "_" + SplitsubFileName[2] + "_" + SplitsubFileName[3] + "_" + SplitsubFileName[4] + "_" + simpleDateFormat.format(currentDate) + ".pdf";
                    try {
                        Path Source = Paths.get(subFile.getPath());
                        Path Target = Paths.get(Folder.getPath() + "//" + NewName);
                        if (!FileIO.FileExistsInDirectory(Folder,subFile)){
                            Files.move(Source, Target, StandardCopyOption.REPLACE_EXISTING);
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            } //else if (){
//                File FileNonTraite = new File(Constant.rootDirectory+"//"+"FileNonTraite");
//                if(!FileNonTraite.exists()){
//                    FileNonTraite.mkdirs();
//                }
//                Path Source = Paths.get(subFile.getPath());
//                Path Target = Paths.get(FileNonTraite+"//"+subFile.getName());
//                Files.move(Source,Target,StandardCopyOption.REPLACE_EXISTING);
//            }
        }
    }
    private static void MainFolder(String directoryPath) throws IOException {
        File file = new File(directoryPath);
        for (File SubFile : file.listFiles()){
            if(SubFile.isDirectory() && !SubFile.getName().equalsIgnoreCase("FileNonTraite") && !SubFile.getName().equalsIgnoreCase("Fusion") && !SubFile.getName().equalsIgnoreCase("OCR") && !SubFile.getName().equalsIgnoreCase("PDF") ){
                MainFolder(SubFile.getAbsolutePath());
            } else if (SubFile.isFile() && isValideTypeFile(SubFile.getName(),"pdf") && !SubFile.getParentFile().getName().equalsIgnoreCase(new File(Constant.rootDirectory).getName())
            ) {
                File finclos = new File(SubFile.getParentFile().getPath()+"//"+"finTraitement.clos");
                if(!finclos.exists()){
                    if (NbrPagePdf(SubFile.getPath())){
                        File PdfFile = new File(SubFile.getParentFile().getPath()+ "//" + "PDF");


                        if (PdfFile.exists()){
                            PdfFile.mkdirs();
                        }
                        Path Source = Paths.get(SubFile.getPath());
                        Path Target =Paths.get(PdfFile+"//"+SubFile.getName());
                        File DestFile = new File(Target.toString());
                        if (!FileIO.FileExistsInDirectory(PdfFile,SubFile)){
                            Files.move(Source,Target,StandardCopyOption.REPLACE_EXISTING);
                        }
                    }else {
                        File OcrFile = new File(SubFile.getParentFile().getPath() + "//" + "OCR");
                        if (!OcrFile.exists()) {
                            OcrFile.mkdirs();
                        }
                        Path Source = Paths.get(SubFile.getPath());
                        Path Target =Paths.get(OcrFile+"//"+SubFile.getName());
                        File DestFile = new File(Target.toString());
                        if (!FileIO.FileExistsInDirectory(OcrFile,SubFile)){
                            Files.move(Source,Target,StandardCopyOption.REPLACE_EXISTING);
                        }
                    }
                }

            }
        }
    }
    private static boolean isValideTypeFile(String Pathfile, String TypeFile){
        File file = new File(Pathfile);
        String FileName = file.getName();
        String extension = "";
        int i =FileName.lastIndexOf('.');
        if (i>=0){
            extension = FileName.substring(i+1);
        }
        return extension.equalsIgnoreCase(TypeFile);
    }
    private static boolean NbrPagePdf(String pathFile) throws IOException {

        PDDocument doc = load(new File(pathFile));
        int count = doc.getNumberOfPages();
        doc.close();
        if (count>1){
            return true;
        }else {
            return false;
        }
    }
    public static boolean IsValideName(String ParentFolderName,String regex){
        return ParentFolderName.matches(regex);
    }
}
