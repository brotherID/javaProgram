package com.example.GCBatch.constant;

public class Constant {

    public static final String rootDirectory = "C:\\Users\\zakaria.elamiri\\workspace";

}
