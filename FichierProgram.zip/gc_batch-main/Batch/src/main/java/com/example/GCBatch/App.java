package com.example.GCBatch;

import com.example.GCBatch.task.MaTask;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;


import java.io.IOException;
import java.util.TimeZone;

import static org.quartz.CronScheduleBuilder.dailyAtHourAndMinute;

/**
 * Hello world!
 *
 */
@Slf4j
public class App 
{


    public static void main( String[] args ) throws IOException, JobExecutionException {

        MaTask maTask = new MaTask();
        maTask.execute();


//        final SchedulerFactory factory = new StdSchedulerFactory();
//        Scheduler scheduler = null;
//        try {
//            scheduler = factory.getScheduler();
//
//            final JobDetail jobDetail = JobBuilder
//                    .newJob(MaTask.class)
//                    .withIdentity("monJob", "groupe_1")
//                    .usingJobData("monParametre", "12345")
//                    .build();
//
//            final Trigger cronTrigger = TriggerBuilder
//                    .newTrigger()
//                    .withIdentity("monTrigger", "groupe_1")
//                    .withSchedule(
//                                CronScheduleBuilder.cronSchedule("0 34 12 ? * *")
//                                    .inTimeZone(TimeZone.getTimeZone("Africa/Casablanca")))
//                    .build();
//
//            scheduler.start();
//            scheduler.scheduleJob(jobDetail, cronTrigger);
//
//            System.in.read();
//            if (scheduler != null) {
//                scheduler.shutdown();
//            }
//        } catch (final SchedulerException e) {
//            e.printStackTrace();
//        } catch (final IOException e) {
//            e.printStackTrace();
//        }
  }
}
