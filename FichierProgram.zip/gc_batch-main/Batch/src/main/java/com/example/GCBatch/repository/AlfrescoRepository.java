package com.example.GCBatch.repository;

import com.example.GCBatch.session.AlfrescoSession;
import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.util.FileUtils;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AlfrescoRepository {
    AlfrescoSession alfrescoSession = new AlfrescoSession();

    public boolean FolderExist(String parentId, String folderName) {
        boolean exist =true;
        Folder parentFolder = FileUtils.getFolder(parentId, alfrescoSession.getSession());
        for (CmisObject children : parentFolder.getChildren()) {
            String  a= children.getName();
            if (children.getProperty("cmis:name").getValueAsString().equals(folderName)) {
                exist = false;
            }
        }
        return exist;
    }

    public void createDocument(String folderId, File file, String mimetype) throws FileNotFoundException {
        Folder oneFolder = findFolderById(folderId);
        Map<String, Object> properties = new HashMap();
        properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
        properties.put(PropertyIds.NAME, file.getName());
        ContentStream contentStream = getContentStream(file, mimetype);
        oneFolder.createDocument(properties, contentStream, null);
    }

    private ContentStream getContentStream(final File file, final String mimetype) throws FileNotFoundException {
        final InputStream inputStream = new FileInputStream(file);
        ContentStream contentStream = new ContentStreamImpl(file.getName(), BigInteger.valueOf(file.length()), mimetype, inputStream);
        return contentStream;
    }
    public String getFolderId(String parentId,String folderName) {
        Folder parentFolder = FileUtils.getFolder(parentId, alfrescoSession.getSession());
        for (CmisObject children : parentFolder.getChildren()) {
            if (children.getProperty("cmis:name").getValueAsString().equals(folderName)) {
                return children.getId();
            }
        }
        return null;
    }
    public void createFolder(String parentId, String folderName) {
        Map<String, Object> properties = new HashMap<>();
        properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
        properties.put(PropertyIds.NAME, folderName);
        findFolderById(parentId).createFolder(properties);
    }

    public Folder findFolderById(String id){
        return FileUtils.getFolder(id, alfrescoSession.getSession());
    }


}
