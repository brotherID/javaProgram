/*
package com.example.GCBatch.service;

import com.example.GCBatch.model.OCRApiRequest;
import com.google.gson.Gson;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class ApiOcrCall {

    public static final String OCRApiUrl = "";

    public static void convertPdfToPdfA(String srcFolder,String dstFolder){
        RestTemplate restTemplate = new RestTemplate();
        OCRApiRequest ocrApiRequest = new OCRApiRequest();
        ocrApiRequest.setDestPath(dstFolder);
        ocrApiRequest.setSrcPath(srcFolder);
        Gson gson = new Gson();
        String jsonRequest = gson.toJson(ocrApiRequest);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(jsonRequest,headers);
        restTemplate.postForObject(OCRApiUrl, entity, String.class);

    }
}
*/