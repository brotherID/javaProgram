package com.example.GCBatch.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OCRApiRequest {

    private String srcPath;
    private String destPath;
}
